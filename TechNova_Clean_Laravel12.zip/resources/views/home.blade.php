@extends('layout')
@section('title', 'TechNova Solutions | Technology Services')
@section('content')
<section class="hero"><div class="eyebrow">Technology • Innovation • Support</div><h1>Smart technology for a connected future.</h1><p>TechNova Solutions helps people and growing businesses make technology simpler through reliable services, practical products, and friendly support.</p><a class="btn" href="/services">Explore our services →</a></section>
<h2 style="margin-top:48px">What we do</h2><div class="grid">
<div class="card"><div class="icon">🖥️</div><h3>IT Support</h3><p>Device setup, troubleshooting, and everyday technology assistance.</p></div>
<div class="card"><div class="icon">🌐</div><h3>Web Solutions</h3><p>Responsive websites and digital tools for organizations and small businesses.</p></div>
<div class="card"><div class="icon">🔒</div><h3>Technology Care</h3><p>Practical guidance for safer, more dependable digital workflows.</p></div>
</div>
@endsection
