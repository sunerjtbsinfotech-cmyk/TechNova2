@extends('layout')
@section('title','Services | TechNova')
@section('content')
<div class="eyebrow">Our services</div><h1 style="color:#0b1730">Technology support that fits your needs.</h1><div class="grid">
<div class="card"><h3>IT Support & Setup</h3><p>Computer setup, software installation, diagnostics, and user support.</p></div>
<div class="card"><h3>Website Development</h3><p>Clean, mobile-friendly business websites and content updates.</p></div>
<div class="card"><h3>Product Guidance</h3><p>Help understanding technology products and choosing suitable solutions.</p></div>
</div>
@endsection
