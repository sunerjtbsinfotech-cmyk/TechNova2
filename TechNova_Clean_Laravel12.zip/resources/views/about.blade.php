@extends('layout')
@section('title','About | TechNova')
@section('content')
<div class="eyebrow">About TechNova</div><h1 style="color:#0b1730">Technology should feel approachable.</h1><p>TechNova Solutions is a student project concept for a technology services business. It presents service information and a simple, responsive web experience built with Laravel.</p>
@endsection
