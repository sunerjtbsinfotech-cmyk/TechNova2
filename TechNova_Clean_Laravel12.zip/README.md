# TechNova Solutions

A clean Laravel 12 starter for a technology services website.

## Requirements
- PHP 8.2+
- Composer
- SQLite or another Laravel-supported database

## Local setup
1. `composer install`
2. Copy `.env.example` to `.env`
3. `php artisan key:generate`
4. Create an empty SQLite file at `database/database.sqlite` (or configure another database)
5. `php artisan serve`

## Pages
- `/` Home
- `/services`
- `/about`
- `/contact`

This starter intentionally has no default administrator account or password. Configure authentication and production environment variables before adding admin features or deploying.
