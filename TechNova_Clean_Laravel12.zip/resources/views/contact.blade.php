@extends('layout')
@section('title','Contact | TechNova')
@section('content')
<div class="eyebrow">Contact</div><h1 style="color:#0b1730">Let’s talk about your project.</h1><div class="card"><p>For this project demo, contact details can be added by the project owner before publication.</p><p><strong>Email:</strong> hello@technova.example</p></div>
@endsection
