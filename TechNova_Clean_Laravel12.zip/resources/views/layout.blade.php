<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>@yield('title', 'TechNova Solutions')</title>
<style>
:root{--navy:#0b1730;--blue:#1769e0;--cyan:#53d8e8;--ink:#17243b;--muted:#64748b;--paper:#f5f8fc}
*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink);background:var(--paper)}
header{background:var(--navy);color:white;padding:18px max(5vw,20px);display:flex;justify-content:space-between;align-items:center;gap:20px;flex-wrap:wrap}
.brand{font-size:1.25rem;font-weight:800;letter-spacing:.3px}.brand span{color:var(--cyan)}
nav{display:flex;gap:20px;flex-wrap:wrap}nav a{color:#dbeafe;text-decoration:none;font-size:.95rem}nav a:hover{color:var(--cyan)}
main{max-width:1120px;margin:auto;padding:58px 22px 80px}.hero{background:linear-gradient(120deg,#0b1730,#123f7c);color:white;border-radius:24px;padding:clamp(32px,7vw,76px);overflow:hidden}
.eyebrow{color:var(--cyan);font-weight:700;letter-spacing:2px;text-transform:uppercase;font-size:.78rem}
h1{font-size:clamp(2.4rem,6vw,4.6rem);line-height:1.04;max-width:760px;margin:16px 0}p{line-height:1.7;color:var(--muted)}.hero p{color:#dbeafe;max-width:650px;font-size:1.1rem}
.btn{display:inline-block;background:var(--cyan);color:#08203b;text-decoration:none;font-weight:800;padding:13px 20px;border-radius:10px;margin-top:14px}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;margin-top:28px}.card{background:white;padding:25px;border:1px solid #e4ebf5;border-radius:16px;box-shadow:0 10px 28px #102a4a0b}.card h3{margin-top:0}.icon{font-size:1.8rem}
footer{background:#081327;color:#b7c7dd;padding:28px max(5vw,20px);text-align:center}
</style>
</head><body>
<header><div class="brand">Tech<span>Nova</span></div><nav><a href="/">Home</a><a href="/services">Services</a><a href="/about">About</a><a href="/contact">Contact</a></nav></header>
<main>@yield('content')</main><footer>© {{ date('Y') }} TechNova Solutions · Technology made practical.</footer>
</body></html>
